# BONECO LENTO 2.0

Projeto Android Kotlin com painel preto/vermelho, status Shizuku, monitoramento básico, detecção/abertura do Free Fire MAX, importação de perfil WireGuard e atalho flutuante.

## Requisitos
Android Studio, JDK 17, Android SDK 35, Android 8.0+.

## Abrir e compilar
1. Extraia o ZIP.
2. Android Studio > Open > escolha `BonecoLento2`.
3. Aguarde o Gradle Sync.
4. Conecte o Android ou inicie um emulador.
5. Run > Run 'app'.
6. APK: Build > Build Bundle(s) / APK(s) > Build APK(s).

## VPN italiana
É necessário um arquivo WireGuard `.conf` fornecido por um provedor legítimo, para servidor localizado na Itália. Importe o arquivo pela tela VPN. O app não inclui servidor, conta ou credenciais. O Android exibirá a autorização VPN. O estado deve ser verificado após a conexão.

## Shizuku
Instale Shizuku pela fonte oficial https://shizuku.rikka.app/. Ative Opções do desenvolvedor > Depuração sem fio, inicie o serviço pelo pareamento e autorize o app no Shizuku. O app mostra status; não executa comandos privilegiados automaticamente.

## Permissões
INTERNET e ACCESS_NETWORK_STATE para rede; SYSTEM_ALERT_WINDOW para o atalho sobre outros apps; FOREGROUND_SERVICE para manter o atalho visível; BIND_VPN_SERVICE é exigida pelo serviço WireGuard. A permissão de sobreposição é concedida nas configurações do Android.

## Limitações desta entrega
- O atalho flutuante abre o painel; não alterna o túnel diretamente.
- Ainda não há exibição de IP público, duração e ping medido.
- O monitoramento apresenta RAM e temperatura da bateria; não é temperatura da CPU.
- O modo lento é apenas demonstrativo na interface, não afeta o jogo.
- O pacote do jogo pode variar conforme distribuição/região.
- O projeto não foi compilado nem testado em dispositivo nesta sessão; valide o Gradle Sync e teste em aparelho antes de distribuir.
