package com.bonecolento.app.overlay
import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.*
import android.widget.TextView
import com.bonecolento.app.MainActivity
class FloatingControlService:Service(){
 private var view:TextView?=null
 private lateinit var wm:WindowManager
 override fun onCreate(){super.onCreate()
  val channel="boneco_overlay"
  if(Build.VERSION.SDK_INT>=26)getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(channel,"VPN shortcut",NotificationManager.IMPORTANCE_LOW))
  val n=if(Build.VERSION.SDK_INT>=26)Notification.Builder(this,channel) else Notification.Builder(this)
  startForeground(802,n.setContentTitle("BONECO LENTO 2.0").setContentText("Floating shortcut active").setSmallIcon(android.R.drawable.ic_lock_lock).build())
  if(!Settings.canDrawOverlays(this)){stopSelf();return}
  wm=getSystemService(Context.WINDOW_SERVICE) as WindowManager
  val type=if(Build.VERSION.SDK_INT>=26)WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
  val p=WindowManager.LayoutParams(-2,-2,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT).apply{gravity=Gravity.TOP or Gravity.END;x=20;y=240}
  view=TextView(this).apply{text="🇮🇹 VPN\nOPEN";textSize=12f;setTextColor(-1);setPadding(20,14,20,14);setBackgroundColor(0xFF991329.toInt());setOnClickListener{startActivity(Intent(this@FloatingControlService,MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))}}
  wm.addView(view,p)
 }
 override fun onDestroy(){view?.let{try{wm.removeView(it)}catch(_:Exception){}};view=null;super.onDestroy()}
 override fun onBind(intent:Intent?):IBinder?=null
}
