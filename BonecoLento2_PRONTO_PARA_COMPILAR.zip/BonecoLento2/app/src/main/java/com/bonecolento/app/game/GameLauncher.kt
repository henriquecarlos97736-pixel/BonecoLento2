package com.bonecolento.app.game
import android.content.Context
class GameLauncher(private val c:Context){
 fun launch():String{
  return try{val i=c.packageManager.getLaunchIntentForPackage("com.dts.freefiremax")?:return "Free Fire MAX not installed.";i.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK);c.startActivity(i);"Launching Free Fire MAX."}
  catch(e:Exception){"Unable to launch: ${e.message}"}
 }
}
