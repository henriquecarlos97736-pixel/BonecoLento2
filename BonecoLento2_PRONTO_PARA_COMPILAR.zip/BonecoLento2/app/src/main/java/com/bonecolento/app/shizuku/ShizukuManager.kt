package com.bonecolento.app.shizuku

import android.content.Context
import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

class ShizukuManager(private val context:Context){
 fun installed()=try{context.packageManager.getPackageInfo("moe.shizuku.privileged.api",0);true}catch(_:Exception){false}
 fun running()=try{Shizuku.pingBinder()}catch(_:Exception){false}
 fun authorized()=try{Shizuku.checkSelfPermission()==PackageManager.PERMISSION_GRANTED}catch(_:Exception){false}
 fun status()=when{!installed()->"NOT INSTALLED";!running()->"SERVICE OFF";authorized()->"AUTHORIZED";else->"PERMISSION NEEDED"}
 fun details()="Installed: ${installed()}\nService running: ${running()}\nAuthorized: ${authorized()}\n\nStart Shizuku through Wireless debugging and authorize this app in Shizuku."
}
