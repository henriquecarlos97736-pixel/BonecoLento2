package com.bonecolento.app.vpn

import android.content.Context
import android.net.VpnService
import android.net.Uri
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config

class WireGuardManager(private val context:Context) {
    private val backend = GoBackend(context)
    private var config:Config? = loadSavedConfig()
    private val tunnel = object: Tunnel {
        override fun getName() = "BonecoLentoItaly"
        override fun onStateChange(newState:Tunnel.State) { }
    }
    private fun loadSavedConfig():Config? = try {
        val value = context.getSharedPreferences("vpn", Context.MODE_PRIVATE).getString("profile_uri", null) ?: return null
        context.contentResolver.openInputStream(Uri.parse(value))?.use { Config.parse(it) }
    } catch (_:Exception) { null }

    fun importConfig(uri:Uri) {
        val flags = android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
        try { context.contentResolver.takePersistableUriPermission(uri, flags) } catch (_:Exception) { }
        val stream = context.contentResolver.openInputStream(uri) ?: error("Cannot read selected file")
        stream.use { config = Config.parse(it) }
        context.getSharedPreferences("vpn", Context.MODE_PRIVATE).edit().putString("profile_uri", uri.toString()).apply()
    }
    fun permissionIntent() = VpnService.prepare(context)
    fun connected() = try { backend.getState(tunnel) == Tunnel.State.UP } catch (_:Exception) { false }
    fun connect() {
        val cfg = config ?: error("Import an Italy WireGuard .conf profile first.")
        if (VpnService.prepare(context) != null) error("Android VPN permission is required.")
        Thread {
            try { backend.setState(tunnel, Tunnel.State.UP, cfg) }
            catch (e:Exception) { android.util.Log.e("BonecoVPN", "Connection failed", e) }
        }.start()
    }
    fun disconnect() {
        Thread {
            try { backend.setState(tunnel, Tunnel.State.DOWN, null) }
            catch (e:Exception) { android.util.Log.e("BonecoVPN", "Disconnect failed", e) }
        }.start()
    }
}
