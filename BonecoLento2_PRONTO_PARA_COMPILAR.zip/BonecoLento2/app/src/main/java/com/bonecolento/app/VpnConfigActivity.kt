package com.bonecolento.app

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.bonecolento.app.vpn.WireGuardManager

class VpnConfigActivity:AppCompatActivity(){
 private val manager by lazy{WireGuardManager(this)}
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState)
  val l=LinearLayout(this).apply{orientation=1;setPadding(24,30,24,24);setBackgroundColor(0xFF050505.toInt())}
  l.addView(TextView(this).apply{text="ITALY VPN CONFIGURATION";textSize=22f;setTextColor(0xFFFF4658.toInt())})
  l.addView(TextView(this).apply{text="Import a WireGuard .conf file from a legitimate VPN provider. Choose a server physically located in Italy. This app does not include a VPN server.";setTextColor(-1);textSize=14f})
  l.addView(Button(this).apply{text="IMPORT .CONF";setOnClickListener{startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="*/*";addCategory(Intent.CATEGORY_OPENABLE)},812)}})
  setContentView(l)
 }
 @Deprecated("Compatibility with older Android versions")
 override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){super.onActivityResult(requestCode,resultCode,data)
  if(requestCode==812 && resultCode==Activity.RESULT_OK){data?.data?.let{try{manager.importConfig(it);Toast.makeText(this,"Configuration imported",Toast.LENGTH_LONG).show();finish()}catch(e:Exception){Toast.makeText(this,e.message,Toast.LENGTH_LONG).show()}}}
 }
}
