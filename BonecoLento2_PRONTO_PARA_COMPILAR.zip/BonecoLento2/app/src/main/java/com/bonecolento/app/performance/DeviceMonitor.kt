package com.bonecolento.app.performance
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
class DeviceMonitor(private val c:Context){
 fun snapshot():String{
  val am=c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
  val m=ActivityManager.MemoryInfo();am.getMemoryInfo(m)
  val used=(m.totalMem-m.availMem)/1024/1024
  val total=m.totalMem/1024/1024
  val b=c.registerReceiver(null,IntentFilter(Intent.ACTION_BATTERY_CHANGED))
  val t=b?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE,-1)?:-1
  return "Device: ${Build.MANUFACTURER} ${Build.MODEL}\nAndroid: ${Build.VERSION.RELEASE}\nRAM: $used MB / $total MB\nBattery temperature: ${if(t>=0) "${t/10.0} °C" else "Unavailable"}\nCPU usage: Not reliably exposed by public Android APIs."
 }
}
