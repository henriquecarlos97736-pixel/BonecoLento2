package com.bonecolento.app

import android.content.*
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.bonecolento.app.game.GameLauncher
import com.bonecolento.app.overlay.FloatingControlService
import com.bonecolento.app.performance.DeviceMonitor
import com.bonecolento.app.shizuku.ShizukuManager
import com.bonecolento.app.vpn.WireGuardManager
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView

class MainActivity : AppCompatActivity() {
    private lateinit var panel: LinearLayout
    private val vpn by lazy { WireGuardManager(this) }
    private val shizuku by lazy { ShizukuManager(this) }
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); render() }

    private fun render() {
        panel = LinearLayout(this).apply { orientation=1; setPadding(22,28,22,24); setBackgroundColor(0xFF050505.toInt()) }
        val scroll=ScrollView(this); scroll.addView(panel); setContentView(scroll)
        text("BONECO LENTO 2.0",27,0xFFFF3347.toInt())
        text("FREE FIRE MAX • DEVICE CONTROL CENTER",11,0xFFAAAAAA.toInt())
        text("SHIZUKU: ${shizuku.status()}    VPN: ${if(vpn.connected()) "CONNECTED" else "DISCONNECTED"}",13,0xFFFF5967.toInt())
        section("SYSTEM OVERVIEW")
        card("Device monitor","RAM, battery temperature, refresh rate") { info("DEVICE",DeviceMonitor(this).snapshot()) }
        card("Shizuku Manager","Installation, service and permission status") { info("SHIZUKU",shizuku.details()) }
        card("Free Fire MAX","Detect and launch com.dts.freefiremax") { toast(GameLauncher(this).launch()) }
        section("ITALY VPN")
        card("Import WireGuard profile","Select a provider .conf file for an Italian server") { startActivity(Intent(this,VpnConfigActivity::class.java)) }
        button("CONNECT VPN") {
            val consent = vpn.permissionIntent()
            if (consent != null) startActivityForResult(consent, 420)
            else try { vpn.connect(); toast("VPN connection requested") } catch(e:Exception){ toast(e.message ?: "VPN error") }
        }
        button("DISCONNECT VPN") { vpn.disconnect(); toast("Disconnect requested") }
        button("FLOATING VPN SHORTCUT") {
            if(!Settings.canDrawOverlays(this)) startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION))
            else { ContextCompat.startForegroundService(this,Intent(this,FloatingControlService::class.java)); toast("Floating shortcut started") }
        }
        section("VISUAL SLOW-MOTION")
        card("Visual demonstration","Adjusts only transitions inside this app, never game behavior") {
            Toast.makeText(this,"Visual demo selected. Game speed is not affected.",Toast.LENGTH_LONG).show()
        }
        section("QUICK SETTINGS")
        button("DISPLAY SETTINGS") { startActivity(Intent(Settings.ACTION_DISPLAY_SETTINGS)) }
        button("NETWORK SETTINGS") { startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS)) }
    }
    @Deprecated("Compatibility with older Android versions")
    override fun onActivityResult(requestCode:Int, resultCode:Int, data:Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 420 && resultCode == RESULT_OK) {
            try { vpn.connect(); toast("VPN connection requested") }
            catch (e:Exception) { toast(e.message ?: "VPN error") }
        }
    }
    private fun section(s:String){ text(s,13,0xFFFF4658.toInt()) }
    private fun text(s:String,size:Int,color:Int){ panel.addView(TextView(this).apply{ text=s; textSize=size.toFloat(); setTextColor(color); setPadding(0,12,0,8) }) }
    private fun card(t:String,d:String,a:()->Unit){
        val c=MaterialCardView(this).apply{ radius=22f; setCardBackgroundColor(0xFF171116.toInt()); strokeWidth=2; setStrokeColor(0xFF751A2B.toInt()) }
        val l=LinearLayout(this).apply{ orientation=1; setPadding(18,14,18,14); addView(TextView(context).apply{text=t; textSize=16f; setTextColor(-1)}); addView(TextView(context).apply{text=d; textSize=12f; setTextColor(0xFFBBBBBB.toInt())}) }
        c.addView(l); c.setOnClickListener{a()}; panel.addView(c,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=10})
    }
    private fun button(s:String,a:()->Unit){ panel.addView(MaterialButton(this).apply{text=s; setOnClickListener{a()}}) }
    private fun info(t:String,m:String){ android.app.AlertDialog.Builder(this).setTitle(t).setMessage(m).setPositiveButton("OK",null).show() }
    private fun toast(s:String?){ Toast.makeText(this,s ?: "Operation completed",Toast.LENGTH_LONG).show() }
}
